/** @file spisplitshuffleplay.cpp
	stephane.poirier@oifii.org or spi@oifii.org
	@ingroup test_src
	@brief Record input into an array; Save array to a file; Playback recorded
    data. Implemented using the blocking API (Pa_ReadStream(), Pa_WriteStream() )
	@author Phil Burk  http://www.softsynth.com
    @author Ross Bencina rossb@audiomulch.com
*/
/*
 * $Id: spisplitshuffleplay.cpp 1368 2008-03-01 00:38:27Z rossb $
 *
 * This program uses the PortAudio Portable Audio Library.
 * For more information see: http://www.portaudio.com
 * Copyright (c) 1999-2000 Ross Bencina and Phil Burk
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * The text above constitutes the entire PortAudio license; however, 
 * the PortAudio community also makes the following non-binding requests:
 *
 * Any person wishing to distribute modifications to the Software is
 * requested to send the modifications to the original developer so that
 * they can be incorporated into the canonical version. It is also 
 * requested that these non-binding requests be included along with the 
 * license above.
 */

#include <stdio.h>
#include <stdlib.h>
#include "portaudio.h"

//2012mar17, spi, begin
#include "WavFile.h"
#include "SoundTouch.h"
using namespace soundtouch;
#define BUFF_SIZE	2048
//2012mar17, spi, end

#include <ctime>
#include <iostream>
#include "WavSet.h"

#include <windows.h>

//Select sample format.
#if 1
#define PA_SAMPLE_TYPE  paFloat32
typedef float SAMPLE;
#define SAMPLE_SILENCE  (0.0f)
#define PRINTF_S_FORMAT "%.8f"
#elif 1
#define PA_SAMPLE_TYPE  paInt16
typedef short SAMPLE;
#define SAMPLE_SILENCE  (0)
#define PRINTF_S_FORMAT "%d"
#elif 0
#define PA_SAMPLE_TYPE  paInt8
typedef char SAMPLE;
#define SAMPLE_SILENCE  (0)
#define PRINTF_S_FORMAT "%d"
#else
#define PA_SAMPLE_TYPE  paUInt8
typedef unsigned char SAMPLE;
#define SAMPLE_SILENCE  (128)
#define PRINTF_S_FORMAT "%d"
#endif

//The event signaled when the app should be terminated.
HANDLE g_hTerminateEvent = NULL;
//Handles events that would normally terminate a console application. 
BOOL WINAPI ConsoleCtrlHandler(DWORD dwCtrlType);
int Terminate();
PaStream* global_pPaStream;
WavSet* global_pWavSet = NULL;
bool global_stopallstreams = false;


// This routine will be called by the PortAudio engine when audio is needed.
// It may called at interrupt level on some machines so don't do anything
// that could mess up the system like calling malloc() or free().
//
static int patestCallback( const void *inputBuffer, void *outputBuffer,
                           unsigned long framesPerBuffer,
                           const PaStreamCallbackTimeInfo* timeInfo,
                           PaStreamCallbackFlags statusFlags,
                           void *userData )
{
    if(global_stopallstreams) return 1; //to stop all streams

	//Cast data passed through stream to our structure.
	WavSet* pWavSet = (WavSet*)userData;//paTestData *data = (paTestData*)userData;
    float *out = (float*)outputBuffer;
    unsigned int i;
    (void) inputBuffer; // Prevent unused variable warning.

	int random_integer;
	int lowest=1, highest=pWavSet->numSegments;
	int range=(highest-lowest)+1;
	random_integer = lowest+int(range*rand()/(RAND_MAX + 1.0));
#ifdef _DEBUG
	printf("idseg=%d\n",random_integer-1);
#endif //_DEBUG
	float* pSegmentData = pWavSet->GetPointerToSegmentData(random_integer-1);
	for( i=0; i<framesPerBuffer; i++ )
    {
        *out++ = *(pSegmentData+2*i);  //left
        *out++ = *(pSegmentData+2*i+1); //right 

        /*
		// Generate simple sawtooth phaser that ranges between -1.0 and 1.0.
        data->left_phase += 0.01f;
        // When signal reaches top, drop back down. 
        if( data->left_phase >= 1.0f ) data->left_phase -= 2.0f;
        // higher pitch so we can distinguish left and right. 
        data->right_phase += 0.03f;
        if( data->right_phase >= 1.0f ) data->right_phase -= 2.0f;
		*/
    }
    return 0;
}

//////
//main
//////
int main(int argc, char *argv[]);
int main(int argc, char *argv[])
{
    PaStreamParameters outputParameters;
    PaError err;

	///////////////////
	//read in arguments
	///////////////////
	char charBuffer[2048] = {"testbeat.wav"}; //usage: spisplitshuffleplay testbeat2.wav 0.5 10
	double fSecondsPerSegment = 1.0; //0.0 for loopplay //non-zero for spliting sample into sub-segments
	int numSecondsShuffle = 10;
	if(argc>1)
	{
		//first argument is the filename
		sprintf_s(charBuffer,2048-1,argv[1]);
	}
	if(argc>2)
	{
		//second argument is the segment length in seconds, 0 for no split and no shuffle i.e. loopplay
		fSecondsPerSegment = atof(argv[2]);
	}
	if(argc>3)
	{
		//third argument is the time it will shuffle
		numSecondsShuffle = atoi(argv[3]);
	}

    //Auto-reset, initially non-signaled event 
    g_hTerminateEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);
    //Add the break handler
    ::SetConsoleCtrlHandler(ConsoleCtrlHandler, TRUE);

	//////////////////////////////////
	//read a WAV file using soundtouch 
	//////////////////////////////////
	global_pWavSet = new WavSet;
	global_pWavSet->ReadWavFile(charBuffer);

	
	////////////////////////////////////
	// play loaded data using port audio 
	////////////////////////////////////
    err = Pa_Initialize();
    if( err != paNoError ) goto error;

	outputParameters.device = Pa_GetDefaultOutputDevice(); // default output device 
	if (outputParameters.device == paNoDevice) 
	{
		fprintf(stderr,"Error: No default output device.\n");
		goto error;
	}
	outputParameters.channelCount = global_pWavSet->numChannels;
	outputParameters.sampleFormat =  PA_SAMPLE_TYPE;
	outputParameters.suggestedLatency = Pa_GetDeviceInfo( outputParameters.device )->defaultLowOutputLatency;
	outputParameters.hostApiSpecificStreamInfo = NULL;

#ifdef _DEBUG //debug: playback the loaded sample file (as is)
	if(0)
	{
		printf("Begin playback.\n"); fflush(stdout);
		err = Pa_OpenStream(
					&global_pPaStream,
					NULL, // no input
					&outputParameters,
					global_pWavSet->SampleRate,
					BUFF_SIZE/global_pWavSet->numChannels, //FRAMES_PER_BUFFER,
					paClipOff,      // we won't output out of range samples so don't bother clipping them 
					NULL, // no callback, use blocking API 
					NULL ); // no callback, so no callback userData 
		if( err != paNoError ) goto error;

		if( global_pPaStream )
		{
			err = Pa_StartStream( global_pPaStream );
			if( err != paNoError ) goto error;
			printf("Waiting for playback to finish.\n"); fflush(stdout);

			err = Pa_WriteStream( global_pPaStream, global_pWavSet->pSamples, global_pWavSet->totalFrames );
			if( err != paNoError ) goto error;

			err = Pa_CloseStream( global_pPaStream );
			if( err != paNoError ) goto error;
			printf("Done.\n"); fflush(stdout);
		}
	}
#endif //_DEBUG

	

	///////////////////////////
	// split WavSet in segments 
	///////////////////////////
	global_pWavSet->SplitInSegments(fSecondsPerSegment);
#ifdef _DEBUG
	printf("numSegments=%d\n",global_pWavSet->numSegments);
#endif //_DEBUG

	//////////////////////////
	//initialize random number
	//////////////////////////
	srand((unsigned)time(0));
	
	///////////////////////////////////////////////////////////////
	//play WavSet's segments randomly using portaudio with callback
	///////////////////////////////////////////////////////////////
	err = Pa_OpenStream(
				&global_pPaStream,
				NULL, // no input
				&outputParameters,
				global_pWavSet->SampleRate,
				global_pWavSet->numSamplesPerSegment/global_pWavSet->numChannels, //BUFF_SIZE/pWavSet->numChannels, //FRAMES_PER_BUFFER,
				paClipOff,      // we won't output out of range samples so don't bother clipping them 
				patestCallback, // no callback, use blocking API 
				global_pWavSet ); // no callback, so no callback userData 
	if( err != paNoError ) goto error;

    err = Pa_StartStream( global_pPaStream );
    if( err != paNoError ) goto error;

    /* Sleep for several seconds. */
    Pa_Sleep(numSecondsShuffle*1000);

	return Terminate();
	


error:
    Pa_Terminate();
    fprintf( stderr, "An error occured while using the portaudio stream\n" );
    fprintf( stderr, "Error number: %d\n", err );
    fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );
    return -1;
}

int Terminate()
{
	/*
	//terminate all playing streams
	global_stopallstreams=true;
	Sleep(1000); //would have to wait fSecondsPerSegment
	*/
	//terminate the only playing stream
    PaError err = Pa_StopStream( global_pPaStream );
    if( err != paNoError ) goto error;


	if( global_pPaStream )
	{
		err = Pa_CloseStream( global_pPaStream );
		if( err != paNoError ) goto error;
		printf("Done.\n"); fflush(stdout);
	}
	Pa_Terminate();
	if(global_pWavSet) delete global_pWavSet;
	printf("Exiting!\n"); fflush(stdout);
	return 0;
error:
    Pa_Terminate();
    fprintf( stderr, "An error occured while using the portaudio stream\n" );
    fprintf( stderr, "Error number: %d\n", err );
    fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );
	return -1;
}

//Called by the operating system in a separate thread to handle an app-terminating event. 
BOOL WINAPI ConsoleCtrlHandler(DWORD dwCtrlType)
{
    if (dwCtrlType == CTRL_C_EVENT ||
        dwCtrlType == CTRL_BREAK_EVENT ||
        dwCtrlType == CTRL_CLOSE_EVENT)
    {
        // CTRL_C_EVENT - Ctrl+C was pressed 
        // CTRL_BREAK_EVENT - Ctrl+Break was pressed 
        // CTRL_CLOSE_EVENT - Console window was closed 
		Terminate();
        // Tell the main thread to exit the app 
        ::SetEvent(g_hTerminateEvent);
        return TRUE;
    }

    //Not an event handled by this function.
    //The only events that should be able to
	//reach this line of code are events that
    //should only be sent to services. 
    return FALSE;
}

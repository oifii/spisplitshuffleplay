////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june01, creation
//2012june04, added EraseSegment(), spi@oifii.org or stephane.poirier@oifii.org
//2012june04, added save segment, spi@oifii.org or stephane.poirier@oifii.org
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////
#define _WAVSET_H
class WavSet
{
public:
	int SampleRate;
	int totalFrames; 
	int numChannels;
	int numSamples;  
	int numBytes;
	float* pSamples;

	int numFramesPerSegment;
	int numSegments;
	int numSamplesPerSegment;  
	int numBytesPerSegment;

	WavSet();
	~WavSet();
	bool ReadWavFile(const char* filename);
	bool SplitInSegments(double fSecondsPerSegment);
	float* GetPointerToSegmentData(int idSegment);
	bool EraseSegment(int idSegment);
};